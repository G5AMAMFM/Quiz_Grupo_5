package com.lasalle.met.quiz;

/**
 * Created by FurruPi on 13/12/17.
 * Fork by TzK 19/12/17
 */
import java.util.ArrayList;

/**
 * Created by Manel on 13/12/17.
 */
public class Singleton {
    private static Singleton mInstance = null;
    private int iHitNbr;
    private int iFailNbr;
    private ArrayList<String> questions = new ArrayList<>();
    private ArrayList<String[]> answers = new ArrayList<>();
    private ArrayList<Integer> correctAnswers = new ArrayList<>();
    private String[] ansTxt;

    private Singleton(){
        questions.add("00110010 00101011 00110010?");
        ansTxt = new String[]{"0010", "0100", "1111"};
        answers.add(ansTxt);
        correctAnswers.add(1);

        questions.add("What is the meaning of life?");
        ansTxt = new String[]{"Yes", "No", "47"};
        answers.add(ansTxt);
        correctAnswers.add(2);

        questions.add("日本語か");
        ansTxt = new String[]{"...", "はい", "いええ"};
        answers.add(ansTxt);
        correctAnswers.add(1);
    }

    public static  Singleton getInstance(){
        if(mInstance == null){
            mInstance = new Singleton();
        }
        return mInstance;
    }

    public void clearNums(){
        this.iHitNbr = 0;
        this.iFailNbr = 0;
    }

    public int getHitNbr(){
        return this.iHitNbr;
    }

    public int getFailNbr(){
        return this.iFailNbr;
    }

    public void incAciertos(){
        this.iHitNbr++;
    }

    public void incFallos(){
        this.iFailNbr++;
    }

    public String getQuestion(int iQPos){
        return this.questions.get(iQPos);
    }

    public String getAnswer(int iQPos, int iAPos){
        String[] sAnswer = this.answers.get(iQPos);
        return sAnswer[iAPos];
    }

    public Boolean isCorrectAnswer(int iQPos, int iAPos){
        if(this.correctAnswers.get(iQPos) == iAPos)
            return true;
        else
            return false;
    }

    public int sizeQuestions(){
        return this.questions.size();
    }
}
