package com.lasalle.met.quiz;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import static com.lasalle.met.quiz.Singleton.getInstance;

/**
 * Created by FurruPi on 13/12/17.
 * Fork by TzK 19/12/17
 */

public class QuizActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private RadioButton rbAnswer1,rbAnswer2,rbAnswer3;
    private TextView textView;
    private Button button;
    private Singleton sQuiz;

    private Integer qCont;
    private Integer iAnswer;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        final String texto = intent.getStringExtra("Extra1");
        setContentView(R.layout.activity_quiz);

        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        textView = (TextView) findViewById(R.id.textView_question);
        button = (Button) findViewById(R.id.button3);
        initializeQuiz();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qCont++; // Next Question
                if (qCont == sQuiz.sizeQuestions()){
                    // Show results in a Toast
                    Toast.makeText(getApplicationContext(),
                            "Result: " + ((Integer)sQuiz.getHitNbr()).toString() + "/" + ((Integer)sQuiz.sizeQuestions()).toString(),
                            Toast.LENGTH_LONG).show();
                    // Convert Button to Restart
                    button.setText("Restart");
                }
                else if (qCont > sQuiz.sizeQuestions()){
                    // Restart
                    initializeQuiz();
                }
                else {
                    correctQuestion((qCont-1),iAnswer);
                    updateQuestion(qCont);
                }
            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.radioButton) {
                    iAnswer = 0;
                } else if(checkedId == R.id.radioButton2) {
                    iAnswer = 1;
                } else {
                    iAnswer = 2;
                }
            }
        });
    }

    private void updateQuestion(int qPos){
        textView.setText(sQuiz.getQuestion(qPos));
        for (int i = 0; i < radioGroup.getChildCount(); i++) {
            ((RadioButton) radioGroup.getChildAt(i)).setText(sQuiz.getAnswer(qPos, i));
        }

        if (qCont == sQuiz.sizeQuestions() - 1){
            button.setText("Finish");
        }
    }

    private void correctQuestion(int qPos,int aPos) {
        if (sQuiz.isCorrectAnswer(qPos, aPos))
            sQuiz.incAciertos();
        else
            sQuiz.incFallos();
    }

    private void initializeQuiz(){
        sQuiz = (Singleton) getInstance();
        sQuiz.clearNums();
        qCont = 0;
        iAnswer = 0;
        updateQuestion(qCont);
        button.setText("Next");
    }
}
